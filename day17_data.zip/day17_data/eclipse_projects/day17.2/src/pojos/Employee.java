package pojos;

import java.sql.Date;

public class Employee {
	//state --properties
	private int id;
	private String name,addr;
	private double salary;
	private int deptId;
	private Date joinDate;
	public Employee(int id, String name, double salary, Date joinDate) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.joinDate = joinDate;
	}
	
	public Employee(String name, String addr, double salary, int deptId, Date joinDate) {
		super();
		this.name = name;
		this.addr = addr;
		this.salary = salary;
		this.deptId = deptId;
		this.joinDate = joinDate;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", addr=" + addr + ", salary=" + salary + ", deptId=" + deptId
				+ ", joinDate=" + joinDate + "]";
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getAddr() {
		return addr;
	}
	public double getSalary() {
		return salary;
	}
	public int getDeptId() {
		return deptId;
	}
	public Date getJoinDate() {
		return joinDate;
	}
	
	

}
