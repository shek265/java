package tester;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import dao.EmpDaoImpl;
import pojos.Employee;

public class TestLayeredApplication {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			// init code -- create DAO instance
			EmpDaoImpl dao = new EmpDaoImpl();
			boolean exit = false;
			while (!exit) {
				System.out.println("1 : get emp dtls 2: Hire Emp 3: Update 4 : Delete Emp dtls 10 : exit");
				System.out.println("Enter option");
				switch (sc.nextInt()) {
				case 1: // display emp details
					System.out.println("Enter dept id strt n end dates");
					List<Employee> l1 = dao.getEmpDetails(sc.nextInt(), Date.valueOf(sc.next()),
							Date.valueOf(sc.next()));
					System.out.println("Emp List");
					for (Employee e : l1)
						System.out.println(e);
					break;
				case 2:
					System.out.println("Enter emp dtls nm adr sal dept_id dt(yr-mon-day)");
					System.out.println("Status " + dao.hireEmployee(new Employee(sc.next(), sc.next(), sc.nextDouble(),
							sc.nextInt(), Date.valueOf(sc.next()))));
					break;

				case 3:
					System.out.println("Enter updated emp dtls empid sal_incr deptid");
					System.out.println("Status " + dao.updateEmp(sc.nextInt(), sc.nextDouble(), sc.nextInt()));
					break;

				case 4:
					System.out.println("Enter emp id to fire");
					System.out.println("Status " + dao.fireEmp(sc.nextInt()));
					break;

				case 10:
					exit = true;
					dao.cleanUp();
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
