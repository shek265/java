package dao;

import java.sql.*;
import static utils.DBUtils.*;

import java.util.ArrayList;
import java.util.List;

import pojos.Employee;

public class EmpDaoImpl implements IEmpDao {
	// d.m
	private Connection cn;
	private PreparedStatement pst1, pst2, pst3,pst4;

	// constr
	public EmpDaoImpl() throws Exception {
		// get cn from DB utils
		cn = fetchConnection();
		// pst1 --select
		pst1 = cn.prepareStatement(
				"select empid,name,salary,join_date from my_emp where dept_id=? and join_date between ? and ?");
		pst2 = cn.prepareStatement("insert into my_emp values(default,?,?,?,?,?)");
		pst3 = cn.prepareStatement("update my_emp set salary=salary+? , dept_id=? where empid=?");
		pst4=cn.prepareStatement("delete from my_emp where empid=?");
		System.out.println("emp dao created");
	}

	// clean up
	public void cleanUp() throws SQLException {
		if (pst1 != null)
			pst1.close();
		if (pst2 != null)
			pst2.close();
		if (pst3 != null)
			pst3.close();
		if (pst4 != null)
			pst4.close();
	
		if (cn != null)
			cn.close();
		System.out.println("emp dao cleaned up...");

	}

	@Override
	public List<Employee> getEmpDetails(int deptId, Date strt, Date end) throws SQLException {
		// create empty list to hold results
		List<Employee> l1 = new ArrayList<>();
		// set IN params
		pst1.setInt(1, deptId);
		pst1.setDate(2, strt);
		pst1.setDate(3, end);
		// exec query
		try (ResultSet rst = pst1.executeQuery()) {
			while (rst.next())
				l1.add(new Employee(rst.getInt(1), rst.getString(2), rst.getDouble(3), rst.getDate(4)));
		}
		return l1;
	}

	@Override
	public String hireEmployee(Employee e) throws SQLException {
		// set IN params
		pst2.setString(1, e.getName());
		pst2.setString(2, e.getAddr());
		pst2.setDouble(3, e.getSalary());
		pst2.setInt(4, e.getDeptId());
		pst2.setDate(5, e.getJoinDate());
		// exec updated
		int updateCount = pst2.executeUpdate();
		if (updateCount == 1)
			return "Emp hiring successful";
		return "Emp hiring failed!!!!!!";
	}

	@Override
	public String updateEmp(int empId, double salIncr, int deptId) throws SQLException {
		//set IN params
		pst3.setDouble(1, salIncr);
		pst3.setInt(2, deptId);
		pst3.setInt(3, empId);
		int cnt=pst3.executeUpdate();
		if (cnt == 1)
			return "Emp updation successful";
		return "Emp updation failed!!!!!!";
	}

	@Override
	public String fireEmp(int empId) throws SQLException {
		// set IN param --emp id
		pst4.setInt(1, empId);
		int cnt=pst4.executeUpdate();
		if (cnt == 1)
			return "Emp firing successful";
		return "Emp firing failed!!!!!!";
	}
	
	

}
