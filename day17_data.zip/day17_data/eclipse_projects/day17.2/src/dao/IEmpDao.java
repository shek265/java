package dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import pojos.Employee;

public interface IEmpDao {
	// add a method to fetch emp dtls
	List<Employee> getEmpDetails(int deptId, Date strt, Date end) throws SQLException;

	// insert emp record
	String hireEmployee(Employee e) throws SQLException;

	// update emp dtls
	String updateEmp(int empId, double salIncr, int deptId) throws SQLException;

	// fire emp
	String fireEmp(int empId) throws SQLException;

}
