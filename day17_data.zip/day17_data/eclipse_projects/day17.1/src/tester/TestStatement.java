package tester;

import static utils.DBUtils.*;
import java.sql.*;

public class TestStatement {

	public static void main(String[] args) {
		String sql = "select empid,name,salary,join_date from my_emp";
		try (// cn
				Connection cn = fetchConnection();
				// st
				Statement st = cn.createStatement();
				// RST
				ResultSet rst = st.executeQuery(sql)) {
			while (rst.next())
				System.out.printf("ID %d Name %s Sal %.2f JoinDate %s %n", rst.getInt(1), rst.getString("name"),
						rst.getDouble(3), rst.getDate(4));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
