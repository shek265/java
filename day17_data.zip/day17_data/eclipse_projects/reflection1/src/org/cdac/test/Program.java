package org.cdac.test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Program {
	public static void printPackageInfo( Class<?> c)
	{
		Package pkg = c.getPackage();
		System.out.println("Package	:	"+pkg.getName());
	}
	public static void printClassInfo( Class<?> c)
	{		
		System.out.println("Class	:	"+c.getSimpleName());
	}
	public static void printFieldInfo( Class<?> c)
	{		
		System.out.println("Field");
		Field[] fields = c.getFields();
		for (Field field : fields) {
			System.out.println(field.toString());
		}
	}
	public static void printMethodInfo( Class<?> c)
	{		
		System.out.println("Method");
		Method[] methods = c.getMethods();
		for (Method method : methods) {
			System.out.println(method.toString());
		}
	}
	public static void printConstructorInfo( Class<?> c)
	{		
		System.out.println("Constructor");
		Constructor<?>[] constructors = c.getConstructors();
		for (Constructor<?> constructor : constructors) {
			System.out.println(constructor.toString());
		}
	}
	public static void main(String[] args) {
		Integer integer = new  Integer(0);
		Class<?> c = integer.getClass();
		System.out.println("----------------------------------------");
		Program.printPackageInfo(c);
		System.out.println("----------------------------------------");
		Program.printClassInfo(c);
		System.out.println("----------------------------------------");
		Program.printFieldInfo(c);
		System.out.println("----------------------------------------");
		Program.printMethodInfo(c);
		System.out.println("----------------------------------------");
		Program.printConstructorInfo(c);
	}
}
