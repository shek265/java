package org.cdac.test;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Scanner;

class Convert {
	public static Object changeType(String value, Parameter parameterType) {
		switch (parameterType.getType().getName()) {
		case "int":
			return Integer.parseInt(value);
		case "float":
			return Float.parseFloat(value);
		}
		return null;
	}
}

public class Program {
	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.print("Enter F.Q. Class Name	:	");
			String className = sc.nextLine(); // math.Calculator
			Class<?> c = Class.forName(className);

			System.out.print("Enter method name	:	");
			String methodName = sc.nextLine(); // sum or sub
			Method[] methods = c.getMethods();

			for (Method method : methods) {
				if (method.getName().equalsIgnoreCase(methodName)) {
					Parameter[] parameters = method.getParameters();
					Object[] arguments = new Object[parameters.length];
					for (int index = 0; index < parameters.length; ++index) {
						System.out.print("Enter value for the argument of " + parameters[index].getType().getName()
								+ " type : ");
						arguments[index] = Convert.changeType(sc.nextLine(), parameters[index]);
					}
					Object obj = c.newInstance();
					Object result = method.invoke(obj, arguments);
					System.out.println("Result	:	" + result);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
