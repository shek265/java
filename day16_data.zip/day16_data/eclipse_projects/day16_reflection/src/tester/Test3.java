package tester;

import java.util.Arrays;
import java.util.Scanner;
import static java.lang.reflect.Modifier.*;
public class Test3 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter name of type to be loaded");
			Class<?> c = Class.forName(sc.next());
			System.out.println("super cls name "+c.getSuperclass().getName());
			System.out.println("i/f names "+Arrays.toString(c.getInterfaces()));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
