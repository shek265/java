package tester;

import java.util.Scanner;

public class Test1 {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in))
		{
			System.out.println("Enter name of class to be loaded");
		  Class<?> c=Class.forName(sc.next());
		  System.out.println(c.isInterface()?"Interface":"Class");
		  Emp e=new Emp(11, "abc", 100);
		 Class<?> c2 =e.getClass();
		  System.out.println("name of loaded cls"+c2.getName());
		  Class<?> c3=String.class;
		  System.out.println(c3.getName());
		  int[] data= {1,2,4,5};
		  System.out.println(data.getClass().getName());
		  int[][] data2= {{1,2,3},{4,5}};
		  System.out.println(data2.getClass().getName());
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
