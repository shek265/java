package tester;

import java.util.Arrays;
import java.util.Scanner;
import static java.lang.reflect.Modifier.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

public class Test5 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			Class<?> c = Class.forName(sc.next());
			// display all constr args
			for(Constructor<?> constr : c.getConstructors())
				System.out.println("constr args "+Arrays.toString(constr.getParameterTypes()));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
