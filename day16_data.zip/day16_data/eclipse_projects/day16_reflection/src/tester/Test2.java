package tester;

import java.util.Scanner;
import static java.lang.reflect.Modifier.*;
public class Test2 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter name of type to be loaded");
			Class<?> c = Class.forName(sc.next());
			System.out.println(c.isInterface() ? "Interface" : "Class");
			int mod=c.getModifiers();
			System.out.println(isPublic(mod)?"public":"default");
			System.out.println(isAbstract(mod)?"abstact":"concrete");
			System.out.println(isFinal(mod)?"final":"non-final");
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
