package tester;

import java.util.Arrays;
import java.util.Scanner;
import static java.lang.reflect.Modifier.*;

import java.lang.reflect.Field;
public class Test4 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			Class<Emp> c=Emp.class;
			//display all field --names n types
			for(Field f : c.getDeclaredFields())
				System.out.println(f.getName()+" : "+f.getType());
			} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
