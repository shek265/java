package utils;

import java.io.IOException;
import java.io.ObjectOutputStream;

import com.app.core.Emp;

public class SerIOUtils {
	//write static method to send emp data to clnt
	public static void writeData(ObjectOutputStream out,Emp e) throws IOException
	{
		out.writeObject(e);
	}
}
