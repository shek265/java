package utils;

import static java.time.LocalDate.parse;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import com.app.core.Dept;
import com.app.core.Emp;

public class CollectionUtils {
	public static HashMap<String, Dept> populateData() {
		HashMap<String, Dept> org = new HashMap<>();
		List<Emp> emps = Arrays.asList(new Emp(12, "abc", 1000, parse("2019-01-01")),
				new Emp(1, "abc2", 5000, parse("2019-11-01")), new Emp(102, "abc3", 3000, parse("2019-06-05")));
		Dept d1 = new Dept("rnd", "mumbai", emps);
		List<Emp> emps2 = Arrays.asList(new Emp(17, "abc4", 11000, parse("2019-01-11")),
				new Emp(10, "abc5", 51000, parse("2019-11-11")), new Emp(100, "abc6", 13000, parse("2019-06-15")));
		Dept d2 = new Dept("hr", "pune", emps2);
		List<Emp> emps3 = Arrays.asList(new Emp(23, "abc8", 12000, parse("2019-11-21")),
				new Emp(65, "abc9", 21000, parse("2019-01-06")), new Emp(78, "abc1", 19000, parse("2019-06-18")));
		Dept d3 = new Dept("finance", "pune", emps3);
		org.put(d1.getDeptId(), d1);
		org.put(d2.getDeptId(), d2);
		org.put(d3.getDeptId(), d3);

		return org;
	}

	// add a static method to retrun max salaried emp
	public static Emp sortEmpsBySal(List<Emp> l1) {
		return Collections.max(l1, new Comparator<Emp>() {

			@Override
			public int compare(Emp o1, Emp o2) {
				// TODO Auto-generated method stub
				return ((Double) o1.getSalary()).compareTo(o2.getSalary());
			}

		});
		
	}
}
