package com.app.core;

import java.io.Serializable;
import java.util.List;

public class Dept implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String deptId, location;
	private List<Emp> emps;
	public Dept(String deptId, String location, List<Emp> emps) {
		super();
		this.deptId = deptId;
		this.location = location;
		this.emps = emps;
	}
	@Override
	public String toString() {
		return "Dept [deptId=" + deptId + ", location=" + location + ", emps=" + emps + "]";
	}
	public String getDeptId() {
		return deptId;
	}
	public String getLocation() {
		return location;
	}
	public List<Emp> getEmps() {
		return emps;
	}
	
	
}
