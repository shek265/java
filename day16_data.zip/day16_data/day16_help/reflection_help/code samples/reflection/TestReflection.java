package reflection;

import java.util.Date;
import java.util.Scanner;

public class TestReflection {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			// for primitives
			Class<?> c = int.class;
			System.out.println(c.getCanonicalName());
			c = Double.class;
			System.out.println(c.getName());
			Date d1 = new Date();
			c = d1.getClass();
			System.out.println(c.getName());
			c=double[].class;
			System.out.println(c.getCanonicalName());
			// prompt for class name
			System.out.println("Enter fully qualified class name to load");
			c = Class.forName(sc.next());
			System.out.println(c.getCanonicalName());
		
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
