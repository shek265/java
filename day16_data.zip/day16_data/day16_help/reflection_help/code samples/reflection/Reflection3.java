package reflection;

import java.lang.reflect.*;
import java.util.Arrays;
import java.util.Scanner;

public class Reflection3 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter class name");
			Class<?> c = Class.forName(sc.next());
			Constructor constr = c.getConstructor(int.class, String.class, double.class);
			Object o=constr.newInstance(101, "abc", 5000);
			System.out.println(o);
			Method m=c.getDeclaredMethod("updateSalary",double.class);
			m.setAccessible(true);
			m.invoke(o,500);
			System.out.println(o);
			

		} catch (Exception e) {
			System.out.println("Err " + e);
		}
	}

}
