package reflection;

import java.lang.reflect.*;
import java.util.Arrays;
import java.util.Scanner;

public class Reflection1 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter class name");
			Class<?> c = Class.forName(sc.next());
			printDetails(c);
			System.out.println("---------------------------------------------");
			printSuperclasses(c);
			System.out.println("---------------------------------------------");
			printInterfaceNames(c);
			System.out.println("---------------------------------------------");
			printFieldNames(c);
			System.out.println("---------------------------------------------");
			printAllFieldNames(c);
			System.out.println("---------------------------------------------");
			showConstructors(c);
			System.out.println("---------------------------------------------");
			showMethods(c);
			System.out.println("---------------------------------------------");
			showAllMethods(c);

		} catch (Exception e) {
			System.out.println("Err " + e);
		}
	}

	static void printDetails(Class<?> c) {
		String s = c.getName();
		System.out.println("class Name " + s + " is " + (c.isInterface() ? " interface" : " class "));
		// display modifiers
		System.out.print("Modifiers  ");
		int m = c.getModifiers();
		if (Modifier.isPublic(m))
			System.out.print("public  ");
		if (Modifier.isAbstract(m))
			System.out.print("abstract  ");
		if (Modifier.isFinal(m))
			System.out.print("final");
		System.out.println();
	}

	static void printSuperclasses(Class<?> subclass) {

		Class<?> superclass;
		System.out.println("Inheritance Hierarchy ");
		while ((superclass = subclass.getSuperclass()) != null) {

			System.out.println(superclass.getName());
			subclass = superclass;
		}
	}

	static void printInterfaceNames(Class<?> c) {
		System.out.println("Interfaces Implemented  ");
		Class<?>[] theInterfaces = c.getInterfaces();
		for (int i = 0; i < theInterfaces.length; i++)
			System.out.println(theInterfaces[i].getName());

	}

	static void printFieldNames(Class<?> c) {
		System.out.println("Accessible Field Details ");
		Field[] publicFields = c.getFields();
		for (int i = 0; i < publicFields.length; i++)
			System.out.println("Field Name: " + publicFields[i].getName() 
					+ " Type: " + publicFields[i].getType());

	}

	static void printAllFieldNames(Class<?> c) {
		System.out.println("All Field Details ");
		Field[] allFields = c.getDeclaredFields();
		Arrays.asList(allFields).
		forEach(f -> System.out.printf("Name : %s Type %s %n",
				f.getName(), f.getType()));
		
	}

	static void showConstructors(Class<?> c1) {

		Constructor<?>[] theConstructors = c1.getConstructors();
		System.out.println("Visible Constructors :");
		Arrays.stream(theConstructors).forEach(c -> {
			System.out.println("Constr args types : ");
			Arrays.stream(c.getParameterTypes()).forEach(System.out::println);
		});
		
		/*
		 * for (int i = 0; i < theConstructors.length; i++) {
		 * System.out.print("( "); Arrays.stream(arg0) Class<?>[] parameterTypes
		 * = theConstructors[i].getParameterTypes(); for (int k = 0; k <
		 * parameterTypes.length; k++)
		 * System.out.print(parameterTypes[k].getName() + " ");
		 * 
		 * System.out.println(")"); }
		 */
	}

	static void showMethods(Class<?> c) {
		System.out.println("Methods");
		Method[] theMethods = c.getMethods();
		for (int i = 0; i < theMethods.length; i++) {
			System.out.println(
					"Name : " + theMethods[i].getName() + " Return Type " + theMethods[i].getReturnType().getName());

			Class<?>[] parameterTypes = theMethods[i].getParameterTypes();
			System.out.print("   Parameter Types : ");
			for (int k = 0; k < parameterTypes.length; k++)
				System.out.print(" " + parameterTypes[k].getName());
			System.out.println();
		}

	}
	static void showAllMethods(Class<?> c) {
		System.out.println("All Methods");
		Method[] theMethods = c.getDeclaredMethods();
		Arrays.stream(theMethods).forEach(m -> {
			System.out.println("Method Name :  "+m.getName());
			System.out.println("Args ");
			Arrays.stream(m.getParameterTypes()).forEach(a->System.out.print(a+" "));
			System.out.println("Ret Type "+m.getReturnType());
		});
		/*for (int i = 0; i < theMethods.length; i++) {
			System.out.println(
					"Name : " + theMethods[i].getName() + " Return Type " + theMethods[i].getReturnType().getName());

			Class<?>[] parameterTypes = theMethods[i].getParameterTypes();
			System.out.print("   Parameter Types : ");
			for (int k = 0; k < parameterTypes.length; k++)
				System.out.print(" " + parameterTypes[k].getName());
			System.out.println();
		}*/

	}
}
