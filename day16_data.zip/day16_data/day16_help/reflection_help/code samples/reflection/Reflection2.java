package reflection;

import java.lang.reflect.*;
import java.util.Arrays;
import java.util.Scanner;

public class Reflection2 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter class name");
			Class<?> c = Class.forName(sc.next());
			Emp e = (Emp) c.newInstance(); // invokes def constructor
			System.out.println(e);
			Constructor constr = c.getConstructor(int.class, String.class, double.class);
			System.out.println(constr.newInstance(101, "abc", 5000));

		} catch (Exception e) {
			System.out.println("Err " + e);
		}
	}

}
