package tester;

import static utils.DBUtils.*;

import java.sql.Connection;

public class TestConnection {

	public static void main(String[] args) {
		try (Connection cn = getConnection()) {
			System.out.println("connected to DB " + cn);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
