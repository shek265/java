package utils;

public class Test3 {
	private static boolean exit;

	public static void main(String[] args) throws Exception {
		SynchroUtils u1 = new SynchroUtils();
		SynchroUtils u2 = new SynchroUtils();
		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				while (!exit)
					u1.test();

			}
		}, "t1");
		Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {
				while (!exit)
					u2.test();

			}
		}, "t2");
		t1.start();
		t2.start();
		System.out.println("Press enter to exit");
		System.in.read();
		exit = true;
		System.out.println("waiting for thrds to complete exec");
		t1.join();
		t2.join();
		System.out.println("main over....");

	}

}
