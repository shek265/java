package com.app.core;

public enum TxType {
	WITHDRAW, DEPOSIT
}
